﻿using MyCVSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyCVSite.ViewModels
{
    public class CoursesListViewModel
    {
        public IEnumerable<Сourse> allCourses { get; set; }

    }
}
