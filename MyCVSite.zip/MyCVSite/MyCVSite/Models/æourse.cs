﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyCVSite.Models
{
    public class Сourse
    {
        public int id { get; set; }
        public DateTime dateTime { get; set; }
        public string desc { get; set; }
        public string img { get; set; }
    }
}
